<tr>
	<td><%= obj.id %></td>
	<td><%= obj.book_issue_id %></td>
	<td><%= obj.book_name %></td>
	<td><%= obj.student_id %></td>
	<td><%= obj.student_name %></td>
	<td><%= obj.issued_at %></td>
	<td><%= obj.return_at %></td>
</tr>